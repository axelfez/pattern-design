package Caso6_Composite;

public interface IValidator {

    String validate(InformacionUsuario informacionUsuario);
}
