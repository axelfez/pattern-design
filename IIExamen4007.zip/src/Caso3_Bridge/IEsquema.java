package Caso3_Bridge;

public interface IEsquema {

    void manageProcess();
}
