package Caso3_Bridge;

public abstract class SistemaOperativo {

    protected IEsquema esquema;

    public abstract void manejarProcesos();

}
